import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Timer, Heart, Brain, CheckCircle2 } from "lucide-react";

export default function CopingTools() {
  const [breathCount, setBreathCount] = useState(0);
  const [isBreathing, setIsBreathing] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const [selfCareItems] = useState([
    { id: 1, label: "Drink water" },
    { id: 2, label: "Take a break" },
    { id: 3, label: "Move your body" },
    { id: 4, label: "Connect with someone" },
    { id: 5, label: "Practice mindfulness" },
  ]);

  const [checkedItems, setCheckedItems] = useState<number[]>([]);

  const startBreathing = () => {
    setIsBreathing(true);
    setBreathCount(0);
    setProgress(0);
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsBreathing(false);
          setBreathCount((prev) => prev + 1);
          return 0;
        }
        return prev + 1;
      });
    }, 50);
  };

  const toggleSelfCareItem = (id: number) => {
    setCheckedItems((prev) => 
      prev.includes(id) 
        ? prev.filter(itemId => itemId !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="relative overflow-hidden">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-primary" />
            Breathing Exercise
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center space-y-4">
            <p className="text-muted-foreground">
              Take deep breaths to help calm your mind
            </p>
            {isBreathing ? (
              <div className="space-y-4">
                <Progress value={progress} className="h-2" />
                <p className="text-lg">
                  {progress <= 50 ? "Breathe in..." : "Breathe out..."}
                </p>
              </div>
            ) : (
              <Button onClick={startBreathing} className="w-full">
                Start Breathing
              </Button>
            )}
            <p className="text-sm text-muted-foreground">
              Completed breaths: {breathCount}
            </p>
          </div>
        </CardContent>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-primary/10 -z-10" />
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-primary" />
            Daily Self-Care Checklist
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {selfCareItems.map((item) => (
              <div key={item.id} className="flex items-center space-x-2">
                <Checkbox
                  id={`item-${item.id}`}
                  checked={checkedItems.includes(item.id)}
                  onCheckedChange={() => toggleSelfCareItem(item.id)}
                />
                <label
                  htmlFor={`item-${item.id}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {item.label}
                </label>
              </div>
            ))}
            <p className="text-sm text-muted-foreground">
              {checkedItems.length} of {selfCareItems.length} completed
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Reflection Prompts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-muted-foreground">Today's prompts:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>What made you smile today?</li>
              <li>Name three things you're grateful for</li>
              <li>What's a small win you can celebrate?</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-primary" />
            Quick Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">When feeling overwhelmed:</p>
            <ul className="space-y-2 list-disc list-inside text-sm">
              <li>Ground yourself: Name 5 things you can see</li>
              <li>Take a short walk if possible</li>
              <li>Listen to calming music</li>
              <li>Reach out to a friend or support person</li>
              <li>Practice self-compassion</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
